#include<stdio.h>
#include<string.h>
void main()
{
int a,b,sum;
printf("enter number:");
scanf("%d",&a);
printf("enter number:");
scanf("%d",&b);
sum=a+b;
printf("sum=%d",sum);

}
END